OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Sluiten",
    "Download" : "Downloaden",
    "Fullscreen" : "Volledig scherm",
    "Loading" : "Laden",
    "Mute" : "Dempen",
    "Next" : "Volgende",
    "of" : "van",
    "Play" : "Spelen",
    "Previous" : "Vorige",
    "Replay" : "Herhalen",
    "Rotate 90° counterclockwise" : "Draai 90 ° tegen de klok in",
    "Zoom in" : "Inzoomen",
    "Zoom out" : "Uitzoomen"
},
"nplurals=2; plural=(n != 1);");
