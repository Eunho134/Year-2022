OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "إغلاق",
    "Download" : "تنزيل",
    "Fullscreen" : "شاشة كاملة",
    "Loading" : "تحميل",
    "Mute" : "كتم الصوت",
    "Next" : "التالي",
    "of" : "من",
    "Play" : "تشغيل",
    "Previous" : "السابق",
    "Replay" : "إعادة التشغيل",
    "Rotate 90° counterclockwise" : "تدوير 90° درجة عكس اتجاه عقارب الساعة",
    "Zoom in" : "تكبير",
    "Zoom out" : "تصغير",
    "Open in Media Viewer" : "فتح في عارض الوسائط"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
