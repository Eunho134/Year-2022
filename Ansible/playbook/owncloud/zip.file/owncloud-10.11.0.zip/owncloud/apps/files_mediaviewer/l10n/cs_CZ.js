OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Zavřít",
    "Download" : "Stáhnout",
    "Fullscreen" : "Přes celou obrazovku",
    "Loading" : "Načítám",
    "Mute" : "Ztlumit",
    "Next" : "Další",
    "of" : "z",
    "Play" : "Přehrát",
    "Previous" : "Předchozí",
    "Replay" : "Přehrát znovu",
    "Rotate 90° counterclockwise" : "Otočit o 90° proti směru hod. ručiček",
    "Zoom in" : "Přiblížit",
    "Zoom out" : "Oddálit"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
