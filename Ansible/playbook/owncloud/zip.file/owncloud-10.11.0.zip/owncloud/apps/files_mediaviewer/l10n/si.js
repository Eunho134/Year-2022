OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "වසන්න",
    "Download" : "බාන්න",
    "Next" : "ඊලඟ",
    "of" : "ගේ",
    "Play" : "ධාවනය",
    "Previous" : "පෙර"
},
"nplurals=2; plural=(n != 1);");
