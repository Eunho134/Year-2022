OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "סגירה",
    "Download" : "הורדה",
    "Fullscreen" : "מסך מלא",
    "Loading" : "טעינה",
    "Mute" : "השתקה",
    "Next" : "הבא",
    "of" : "מתוך",
    "Play" : "נגינה",
    "Previous" : "הקודם",
    "Replay" : "לנגן מחדש",
    "Rotate 90° counterclockwise" : "להטות ב־90° נגד כיוון השעון",
    "Zoom in" : "התקרבות",
    "Zoom out" : "התרחקות"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
