OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Pechar",
    "Download" : "Descargar",
    "Fullscreen" : "Pantalla completa",
    "Loading" : "Cargando",
    "Mute" : "Silenciar",
    "Next" : "Seguinte",
    "of" : "de",
    "Play" : "Reproducir",
    "Previous" : "Anterior",
    "Replay" : "Repetir",
    "Rotate 90° counterclockwise" : "Rotar 90° no sentido contrario das agullas do reloxo",
    "Zoom in" : "Achegar",
    "Zoom out" : "Afastar"
},
"nplurals=2; plural=(n != 1);");
