OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Zamknij",
    "Download" : "Pobierz",
    "Fullscreen" : "Pełny ekran",
    "Loading" : "Ładowanie",
    "Mute" : "Wycisz",
    "Next" : "Następny",
    "of" : "z",
    "Play" : "Odtwarzaj",
    "Previous" : "Poprzedni",
    "Replay" : "Powtarzaj",
    "Rotate 90° counterclockwise" : "Obróć o 90° przeciwnie do ruchu wskazówek zegara",
    "Zoom in" : "Przybliż",
    "Zoom out" : "Oddal"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
