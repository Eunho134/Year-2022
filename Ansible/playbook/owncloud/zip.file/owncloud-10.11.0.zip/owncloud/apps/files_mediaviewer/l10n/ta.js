OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "மூடுக",
    "Download" : "பதிவிறக்குக",
    "Next" : "அடுத்த",
    "of" : "உடைய",
    "Play" : "Play",
    "Previous" : "முன்தைய"
},
"nplurals=2; plural=(n != 1);");
