OC.L10N.register(
    "files_mediaviewer",
    {
    "Close" : "Fermer",
    "Download" : "Télécharger",
    "Fullscreen" : "Plein écran",
    "Loading" : "Chargement",
    "Mute" : "Muet",
    "Next" : "Suivant",
    "of" : "sur",
    "Play" : "Lire",
    "Previous" : "Précédent",
    "Replay" : "Relire",
    "Rotate 90° counterclockwise" : "Rotation de 90° dans le sens anti-horaire",
    "Zoom in" : "Zoomer",
    "Zoom out" : "Dé-zoomer",
    "Open in Media Viewer" : "Ouvrir avec Media Viewer"
},
"nplurals=2; plural=(n > 1);");
