OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notificaciones",
    "No notifications" : "No hay notificaciones",
    "Dismiss" : "Descartar",
    "Admin notifications" : "Notificaciones del administrador",
    "Unknown user session. It is not possible to set the option" : "Sesión de usuario desconocida. No es posible establecer la opción.",
    "Option not supported" : "Opción no soportada",
    "Saved" : "Guardado",
    "Incomplete data" : "Información incompleta",
    "Do not notify via mail" : "No notificar por correo electrónico",
    "Notify only when an action is required" : "Notificar solamente cuando se requiere una acción",
    "Notify about all events" : "Notificar acerca de todos los eventos",
    "Choose an option" : "Elige una opción",
    "Hello," : "Hola,",
    "See <a href=\"%s\">%s</a> on %s for more information" : "Consulta <a href=\"%s\">%s</a> en %s para más información",
    "See %s on %s for more information" : "Consulta %s en %s para más información",
    "Mail Notifications" : "Notificaciones por correo electrónico.",
    "You can choose to be notified about events via mail. Some events are informative, others require an action (like accept/decline). Select your preference below:" : "Puedes elegir ser notificado acerca de eventos por medio de correo electrónico. Algunos eventos son informativos, otros requieren una acción (como aceptar/declinar). Selecciona tu preferencia abajo:",
    "It was not possible to get your session. Please, try reloading the page or logout and login again" : "No fue posible obtener tu sesión. Por favor, intenta recargar la página o sal y entra de nuevo.",
    "To be able to receive mail notifications it is required to specify an email address for your account." : "Para poder recibir notificaciones por correo electrónico se debe especificar una dirección de correo para tu cuenta."
},
"nplurals=2; plural=(n != 1);");
