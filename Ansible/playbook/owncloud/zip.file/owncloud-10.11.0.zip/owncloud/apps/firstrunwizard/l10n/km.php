<?php
$TRANSLATIONS = array(
"Welcome to %s" => "សូម​ស្វាគមន៍​មក​កាន់ %s",
"Your personal web services. All your files, contacts, calendar and more, in one place." => "សេវាកម្ម​វេប​ផ្ទាល់​ខ្លួន​របស់​អ្នក។ ",
"Get the apps to sync your files" => "ដាក់​អោយកម្មវិធីផ្សេងៗ ​ធ្វើសមកាលកម្ម​ឯកសារ​អ្នក",
"Connect your desktop apps to %s" => "ភ្ជាប់​កម្មវិធី​លើ​កុំព្យូទ័រ​របស់​អ្នក​ទៅ %s",
"Connect your Calendar" => "ភ្ជាប់​ប្រតិទិន​របស់​អ្នក",
"Documentation" => "កម្រង​ឯកសារ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
