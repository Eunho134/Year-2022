# market
:convenience_store: MarketPlace/AppStore integration

[![Build Status](https://drone.owncloud.com/api/badges/owncloud/market/status.svg?branch=master)](https://drone.owncloud.com/owncloud/market)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=owncloud_market&metric=alert_status)](https://sonarcloud.io/dashboard?id=owncloud_market)
[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=owncloud_market&metric=security_rating)](https://sonarcloud.io/dashboard?id=owncloud_market)
[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=owncloud_market&metric=coverage)](https://sonarcloud.io/dashboard?id=owncloud_market)

See the [Frontend development](https://github.com/owncloud/market/wiki/Frontend-development-(WIP)) document to get going.
