OC.L10N.register(
    "files_external",
    {
    "Step 1 failed. Exception: %s" : "Schritt 1 ist fehlgeschlagen. Ausnahme: %s",
    "Step 2 failed. Exception: %s" : "Schritt 2 ist fehlgeschlagen. Ausnahme: %s",
    "Google Drive App Configuration" : "Google Drive App Konfigurierung",
    "Error verifying OAuth2 Code for " : "Bei der Verifikation des OAuth2 Codes für [ ] ist ein Fehler aufgetreten.",
    "Personal" : "Persönlich",
    "Saved" : "Gespeichert",
    "Username" : "Benutzername",
    "Password" : "Passwort",
    "Save" : "Speichern",
    "Google Drive" : "Google Drive",
    "Location" : "Ort",
    "Host" : "Host",
    "Root" : "Root",
    "Share" : "Freigeben",
    "Name" : "Name",
    "Folder name" : "Ordner Name",
    "Delete" : "Löschen"
},
"nplurals=2; plural=(n != 1);");
