OC.L10N.register(
    "files_external",
    {
    "Share" : "वाटा",
    "Name" : "नाव",
    "Delete" : "का"
},
"nplurals=2; plural=(n != 1);");
