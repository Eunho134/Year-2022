OC.L10N.register(
    "files_external",
    {
    "Username" : "Nama pengguna",
    "Password" : "Kata Sandi",
    "Delete" : "Hapus"
},
"nplurals=1; plural=0;");
