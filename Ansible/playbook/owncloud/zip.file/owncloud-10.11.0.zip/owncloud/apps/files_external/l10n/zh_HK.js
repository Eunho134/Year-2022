OC.L10N.register(
    "files_external",
    {
    "Personal" : "個人",
    "Saved" : "已儲存",
    "Username" : "用戶名稱",
    "Password" : "密碼",
    "Save" : "儲存",
    "WebDAV" : "WebDAV",
    "URL" : "網址",
    "Location" : "位置",
    "Host" : "主機",
    "Share" : "分享",
    "Name" : "名稱",
    "Folder name" : "資料夾名稱",
    "Delete" : "刪除"
},
"nplurals=1; plural=0;");
