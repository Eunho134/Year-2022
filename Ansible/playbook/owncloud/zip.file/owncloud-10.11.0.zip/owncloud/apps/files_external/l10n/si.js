OC.L10N.register(
    "files_external",
    {
    "External storage" : "බාහිර ආචයනය",
    "Google Drive App Configuration" : "ගූගල් ඩ්‍රයිව් යෙදුමේ වින්‍යාසය",
    "Personal" : "පෞද්ගලික",
    "System" : "පද්ධතිය",
    "(group)" : "(සමූහය)",
    "All users" : "සියළුම පරිශීලකයින්",
    "Saved" : "සුරැකිණි",
    "Username" : "පරිශීලක නම",
    "Password" : "මුර පදය",
    "Save" : "සුරකින්න",
    "URL" : "URL",
    "Location" : "ස්ථානය",
    "Host" : "සත්කාරකය",
    "Share" : "බෙදා හදා ගන්න",
    "Name" : "නම",
    "Folder name" : "ෆොල්ඩරයේ නම",
    "Configuration" : "වින්‍යාසය",
    "Delete" : "මකා දමන්න"
},
"nplurals=2; plural=(n != 1);");
